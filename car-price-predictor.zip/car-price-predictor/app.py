# importing necessary libraries and functions
import numpy as np
from flask import Flask, request, jsonify, render_template
import pickle
import sklearn

#Initializing the flask App
app = Flask(__name__) 
# loading the trained model
model = pickle.load(open('model.pkl', 'rb')) 

# Homepage
@app.route('/', methods=['GET']) 
def Home():
    return render_template('index.html')

# Predicting car price
@app.route('/predict',methods=['POST'])
def predict():
    if request.method == 'POST':
        Present_Price=float(request.form['Present_Price'])
        Kms_Driven=int(request.form['Kms_Driven'])
        Owner=int(request.form['Owner'])
        Fuel_Type=request.form['Fuel_Type']
        Age_of_the_car=request.form['Age_of_the_car']
        Seller_Type=request.form['Seller_Type']
        Transmission=request.form['Transmission']

        prediction=model.predict([[Present_Price, Kms_Driven, Owner, Age_of_the_car, Fuel_Type, Seller_Type, Transmission]])
        output= round(prediction[0],2)
        return render_template('index.html', prediction_text="You can sell your car at {} lakhs". format(output))

if __name__ == "__main__":
    app.run(debug=True)